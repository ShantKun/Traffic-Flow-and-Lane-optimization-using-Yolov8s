# My First Project > 2025-03-09 3:46am
https://universe.roboflow.com/sidlovessweenysfart/my-first-project-dpd52

Provided by a Roboflow user
License: CC BY 4.0

